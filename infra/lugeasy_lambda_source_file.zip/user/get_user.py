def get_user():
    return "get user!"